﻿using BitmonGeneration1.Source.Battles;
using System;
using System.Threading;

namespace BitmonStadiumConsoleApp
{
    public static class BattleEventsHandler
    {
        public static void AttachMyBattleBitmonEventHandlers(BattleBitmon myBit)
        {
            //bitmon events
            myBit.Burned += MyBurnedEventHandler;
            myBit.Frozen += MyFrozenEventHandler;
            myBit.Paralyzed += MyParalyzedEventHandler;
            myBit.Poisoned += MyPoisonedEventHandler;
            myBit.BadlyPoisoned += MyBadlyPoisonedEventHandler;
            myBit.FellAsleep += MyFellAsleepEventHandler;
            myBit.StatusCleared += MyStatusClearedEventHandler;
            myBit.Fainted += MyFaintedEventHandler;

            //move events
            myBit.MoveUsed += MyMoveUsedEventHandler;
            
            myBit.AttackContinues += MyAttackContinuesEventHandler;
           

            //battleBitmon events
            myBit.SwitchedOut += MySwitchedOutEventHandler;
           
        }
        public static void AttachOpponentBattleBitmonEventHandlers(BattleBitmon enemyBit)
        {
            //bitmons events
            enemyBit.SwitchedOut += EnemySwitchedOutEventHandler;
            enemyBit.Burned += EnemyBurnedEventHandler;
            enemyBit.Frozen += EnemyFrozenEventHandler;
            enemyBit.Paralyzed += EnemyParalyzedEventHandler;
            enemyBit.Poisoned += EnemyPoisonedEventHandler;
            enemyBit.BadlyPoisoned += EnemyBadlyPoisonedEventHandler;
            enemyBit.FellAsleep += EnemyFellAsleepEventHandler;
            enemyBit.StatusCleared += EnemyStatusClearedEventHandler;
            enemyBit.Fainted += EnemyFaintedEventHandler;

            //move events
            enemyBit.MoveUsed += EnemyMoveUsedEventHandler;
            
            enemyBit.AttackContinues += EnemyAttackContinuesEventHandler;
            

           
        }
        public static void AttachBattleEventHandlers(Battle battle)
        {
            battle.BattleBegun += BattleBegunEventHandler;
            battle.BattleOver += BattleOverEventHandler;
            battle.MakingSelections += MakingSelectionsEventHandler;
            battle.FirstExecutionBegun += FirstExecutionBegunHandler;
            battle.FirstExecutionOver += FirstExecutionOverHandler;
            battle.SecondExecutionBegun += SecondExecutionBegunHandler;
            battle.SecondExecutionOver += SecondExecutionOverHandler;
        }




        //===================================================================================//
        //                          BATTLE EVENT HANDLERS                                    //
        //===================================================================================//
        private static void BattleBegunEventHandler(object sender, BattleEventArgs args)
        {
            Console.WriteLine("Battle has begun!");
            Thread.Sleep(2700);
            Console.Clear();
        }
        private static void BattleOverEventHandler(object sender, BattleEventArgs args)
        {
            Console.Clear();
            DisplayBitmon(args);
            Console.WriteLine();
            Console.WriteLine("Battle over!");
            Thread.Sleep(2500);
            if (args.thisBattle.IsPlayerDefeated)
            {
                Console.WriteLine("Player lost!");
                Console.WriteLine();
            }
            else
            {
                Console.WriteLine("You won!");
                Console.WriteLine();
            }
        }
        private static void MakingSelectionsEventHandler(object sender, BattleEventArgs args)
        {
            DisplayBitmon(args);
        }
        private static void FirstExecutionBegunHandler(object sender, BattleEventArgs args)
        {
            Console.Clear();
            DisplayBitmon(args);
        }
        private static void FirstExecutionOverHandler(object sender, BattleEventArgs args)
        {
            Thread.Sleep(2200);
        }
        private static void SecondExecutionBegunHandler(object sender, BattleEventArgs args)
        {
            Console.Clear();
            DisplayBitmon(args);
        }
        private static void SecondExecutionOverHandler(object sender, BattleEventArgs args)
        {
            Thread.Sleep(2200);
        }
        private static void DisplayBitmon(BattleEventArgs args)
        {
            Display.Bitmon(args.thisBattle.PlayerSide.CurrentBattleBitmon,
                            args.thisBattle.OpponentSide.CurrentBattleBitmon,
                            args.thisBattle.PlayerSide.Name,
                            args.thisBattle.OpponentSide.Name);
        }
        


        //===================================================================================//
        //                          EVENT HANDLERS                                    //
        //===================================================================================//
        private static void MyBurnedEventHandler(object sender, BattleBitmonEventArgs args)
        {
            Console.WriteLine(args.battleBitmon.Name + " was burned!");
        }
        private static void EnemyBurnedEventHandler(object sender, BattleBitmonEventArgs args)
        {
            Console.WriteLine("Enemy " + args.battleBitmon.Name + " was burned!");
        }
        private static void MyFrozenEventHandler(object sender, BattleBitmonEventArgs args)
        {
            Console.WriteLine(args.battleBitmon.Name + " was frozen!");
        }
        private static void EnemyFrozenEventHandler(object sender, BattleBitmonEventArgs args)
        {
            Console.WriteLine("Enemy " + args.battleBitmon.Name + " was frozen!");
        }
        private static void MyParalyzedEventHandler(object sender, BattleBitmonEventArgs args)
        {
            Console.WriteLine(args.battleBitmon.Name + " was paralyzed!");
        }
        private static void EnemyParalyzedEventHandler(object sender, BattleBitmonEventArgs args)
        {
            Console.WriteLine("Enemy " + args.battleBitmon.Name + " was paralyzed!");
        }
        private static void MyPoisonedEventHandler(object sender, BattleBitmonEventArgs args)
        {
            Console.WriteLine(args.battleBitmon.Name + " was poisoned!");
        }
        private static void EnemyPoisonedEventHandler(object sender, BattleBitmonEventArgs args)
        {
            Console.WriteLine("Enemy " + args.battleBitmon.Name + " was poisoned!");
        }
        private static void MyBadlyPoisonedEventHandler(object sender, BattleBitmonEventArgs args)
        {
            Console.WriteLine(args.battleBitmon.Name + " was badly poisoned!");
        }
        private static void EnemyBadlyPoisonedEventHandler(object sender, BattleBitmonEventArgs args)
        {
            Console.WriteLine("Enemy " + args.battleBitmon.Name + " was badly poisoned!");
        }
        private static void MyFellAsleepEventHandler(object sender, BattleBitmonEventArgs args)
        {
            Console.WriteLine(args.battleBitmon.Name + " fell asleep!");
        }
        private static void EnemyFellAsleepEventHandler(object sender, BattleBitmonEventArgs args)
        {
            Console.WriteLine("Enemy " + args.battleBitmon.Name + " fell asleep!");
        }
        private static void MyStatusClearedEventHandler(object sender, BattleBitmonEventArgs args)
        {
            Console.WriteLine(args.battleBitmon.Name + "'s status was cleared!");
        }
        private static void EnemyStatusClearedEventHandler(object sender, BattleBitmonEventArgs args)
        {
            Console.WriteLine("Enemy " + args.battleBitmon.Name + "'s status was cleared!");
        }
        private static void MyFaintedEventHandler(object sender, BattleBitmonEventArgs args)
        {
            Console.WriteLine(args.battleBitmon.Name + " fainted!");
        }
        private static void EnemyFaintedEventHandler(object sender, BattleBitmonEventArgs args)
        {
            Console.WriteLine("Enemy " + args.battleBitmon.Name + " fainted!");
        }
        


        //===================================================================================//
        //                           MOVE EVENT HANDLERS                                     //
        //===================================================================================//
        private static void MyMoveUsedEventHandler(MoveEventArgs args)
        {
            Console.WriteLine();
            Console.WriteLine(args.bitmon.Nickname + " used " + args.move.Name + "!");
            Thread.Sleep(1500);
        }
        private static void EnemyMoveUsedEventHandler(MoveEventArgs args)
        {
            Console.WriteLine();
            Console.WriteLine("Enemy " + args.bitmon.Nickname + " used " + args.move.Name + "!");
            Thread.Sleep(1500);
        }
       
        private static void MyAttackContinuesEventHandler(MoveEventArgs args)
        {
            Console.WriteLine(args.battleBitmon.Name + "'s attack continues!");
        }
        private static void EnemyAttackContinuesEventHandler(MoveEventArgs args)
        {
            Console.WriteLine("Enemy " + args.battleBitmon.Name + "'s attack continues!");
        }
        



        //===================================================================================//
        //                       BATTLE BITMON EVENT HANDLERS                               //
        //===================================================================================//
        private static void MySwitchedOutEventHandler(object sender, SwitchedOutEventArgs args)
        {
            Console.WriteLine("Come back " + args.bitmon.Nickname + "!");
            Thread.Sleep(2200);
            Console.WriteLine("Go " + args.switchIn.Nickname + "!");
            Thread.Sleep(2200);
        }
        private static void EnemySwitchedOutEventHandler(object sender, SwitchedOutEventArgs args)
        {
            Console.WriteLine( args.bitmon.Nickname + "Come back!");
            Thread.Sleep(2200);
            Console.WriteLine("Go " + args.switchIn.Nickname + "!");
            Thread.Sleep(2200);
        }
       

    }
}
