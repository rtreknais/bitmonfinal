﻿namespace BitmonGeneration1.Source.Battles
{
    public enum StatType
    {
        Attack,
        Defense,
        Special,
        Speed,
        Accuracy,
        Evasion
    }
}
