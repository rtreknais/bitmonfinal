﻿using BitmonGeneration1.Source.BitmonData;
using BitmonGeneration1.Source.Trainers;
using System;
using System.Linq;
using System.Collections.Generic;

namespace BitmonGeneration1.Source.Battles
{
    public abstract class Side
    {
        protected Selection Selection;
        protected int FleeAttempts;

        public abstract string Name { get; }
        public abstract List<Bitmon> Party { get; }
        public abstract bool IsDefeated { get; }

        public BattleBitmon CurrentBattleBitmon { get; }


        public int SelectionPriority => Selection.Priority;


        public void ExecuteSelection()
        {
            Selection.Execute();
        }

        public void SetSelection(Selection selection)
        {
            Selection = selection;
        }

        public bool IsBitmonFainted()
        {
            return CurrentBattleBitmon.IsFainted;
        }

        protected Side(BattleBitmon currentBattleBitmon)
        {
            CurrentBattleBitmon = currentBattleBitmon;
        }
    }




    public sealed class WildBitmonSide : Side
    {
        private Bitmon bitmon;


        public WildBitmonSide(Bitmon bitmon) :
            base(new BattleBitmon(bitmon))
        {
            this.bitmon = bitmon;
        }

        public sealed override bool IsDefeated
            => CurrentBattleBitmon.IsFainted;

        public sealed override string Name
            =>  "";

        public sealed override List<Bitmon> Party
            => new List<Bitmon>(1) { bitmon };
    }





    public class TrainerSide : Side
    {
        Trainer Trainer;

        public TrainerSide(Trainer trainer) :
            base(new BattleBitmon(trainer.Party()[0]))
        {
            Trainer = trainer;
        }

        
        public sealed override bool IsDefeated
            => Trainer.Party().All(p => p.Status == Status.Fainted);

        public sealed override string Name
            => Trainer.Name;

        public sealed override List<Bitmon> Party
            => Trainer.Party();
    }

    public class TrainerSide2 : Side
    {
        Trainer Trainer;

        public TrainerSide2(Trainer trainer) :
            base(new BattleBitmon(trainer.Party()[0]))
        {
            Trainer = trainer;
        }


        public sealed override bool IsDefeated
            => Trainer.Party().All(p => p.Status == Status.Fainted);

        public sealed override string Name
            => Trainer.Name;

        public sealed override List<Bitmon> Party
            => Trainer.Party();
    }



}
