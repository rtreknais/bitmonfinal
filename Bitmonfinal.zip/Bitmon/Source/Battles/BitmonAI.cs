﻿using BitmonGeneration1.Source.Moves;
using BitmonGeneration1.Source.Battles;
using System;
using BitmonGeneration1.Source.BitmonData;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using BitmonStadiumConsoleApp;

namespace BitmonGeneration1.Source.Battles
{
    public class BitmonAI : BattleActor
    {
        public Selection MakeBeginningOfTurnSelection(Battle battle, Side actorSide)
        {
            if (actorSide.CurrentBattleBitmon.IsMultiTurnMoveActive())
            {
                return Selection.MakeContinueMultiTurnMove(actorSide.CurrentBattleBitmon,
                                                           battle.PlayerSide.CurrentBattleBitmon);
            }
            else if (actorSide.CurrentBattleBitmon.PartiallyTrapped)
            {
                return Selection.MakeEmptyFight();
            }
            else
            {
                return MakeRandomFightSelection(battle, actorSide);
            }
        }
        private Selection MakeRandomFightSelection(Battle battle, Side actorSide)
        {
            return Selection.MakeFight(actorSide.CurrentBattleBitmon,
                                       battle.PlayerSide.CurrentBattleBitmon,
                                       PickRandomMove(actorSide));
        }
        private Move PickRandomMove(Side actorSide)
        {
            var nut = actorSide.CurrentBattleBitmon;
            var rng = new Random();
            Move move = null;
            while (move == null)
            {
                int rando = rng.Next(1, 5);
                if (rando == 1 &&
                    nut.Move1 != null)
                {
                    move = nut.Move1;
                }
                else if (rando == 2 &&
                         nut.Move2 != null)
                {
                    move = nut.Move2;
                }
                else if (rando == 3 &&
                         nut.Move3 != null)
                {
                    move = nut.Move3;
                }
                else if (rando == 4 &&
                         nut.Move4 != null)
                {
                    move = nut.Move4;
                }
            }
            return move;
        }

        private static Selection SwitchBitmonPrompt(Battle battle, Side actorSide)
        {
            Selection selection;
            Console.Clear();
            Display.BitmonPrompt(actorSide);

            int bitmonPick;
            while (!int.TryParse(Console.ReadLine(), out bitmonPick)
                  || bitmonPick < 1
                  || bitmonPick > actorSide.Party.Count
                  || actorSide.Party[bitmonPick - 1].Status == Status.Fainted
                  || actorSide.Party[bitmonPick - 1] == actorSide.CurrentBattleBitmon.Bitmon)
            {
                Console.Clear();
                Display.BitmonPrompt(actorSide);
            }

            selection = Selection.MakeSwitchOut(
                actorSide.CurrentBattleBitmon,
                battle.OpponentSide.CurrentBattleBitmon,
                actorSide.Party[bitmonPick - 1]);

            Console.Clear();
            Display.Bitmon(
                actorSide.CurrentBattleBitmon,
                battle.OpponentSide.CurrentBattleBitmon,
                actorSide.Name,
                battle.OpponentSide.Name);

            return selection;
        }
        public Selection MakeForcedSwitchSelection(Battle battle, Side actorSide)
        {
            return SwitchBitmonPrompt(battle, actorSide);
        }


        public Move PickMoveToMimic(Side opponentSide)
        {
            throw new NotImplementedException();
        }

        public Selection MakeForcedSwitchSelection1(Battle battle, Side enemySide)
        {
            throw new NotImplementedException();
        }

        public Selection MakeBeginningOfTurnSelection1(Battle battle, Side enemySide)
        {
            throw new NotImplementedException();
        }

       
    }
}
