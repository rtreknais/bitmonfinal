﻿using System;
using BitmonGeneration1.Source.Battles;

namespace BitmonGeneration1.Source.Moves.Reflexive
{

    //14
    public sealed class Rest : ReflexiveStatusMove
    {
        protected sealed override void Execute(BattleBitmon user)
        {
            OnUsed();
            user.SleepFor(2);
            user.RestoreHP(user.MaxHP);
            SetLastMoveAndSubtractPP(user);
        }

        public Rest() : base(156, "Rest", Type.Psychic, 10, 16) { }
    }
}
