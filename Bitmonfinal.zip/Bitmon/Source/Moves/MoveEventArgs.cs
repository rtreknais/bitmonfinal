﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BitmonGeneration1.Source.Moves
{
    public class MoveEventArgs : EventArgs
    {
        public Move move;
    }
}
