﻿namespace BitmonGeneration1.Source.BitmonData
{
    public static class SpeciesData
    {

        public static readonly string[] Names = new string[]
        {
            "Null",
            "Charmon", // 1
            "Bitmeleon",
            "Pikamon",
            "Qwertymon",
            "Squimon",
            "Worbimon",
            "Icemon",
            "Dragonice",
            "Tirimon",
            "Naidormon", //10
            
        };





        public static readonly Type[][] Types = new Type[][]
        {
            //0 - No Pokemon
            new Type[] { Type.Null, Type.Null },
            //1 - Charmon                     
            new Type[] { Type.Fire, Type.Null },
            //2 - Bitmeleon
            new Type[] { Type.Fire, Type.Null },
            //3 - Pikamon
            new Type[] { Type.Electric, Type.Null },
            //4 - Qwertymon
            new Type[] { Type.Electric, Type.Null },
            //5 - Squimon
            new Type[] { Type.Water, Type.Null },
            //6 - Worbimon
            new Type[] { Type.Water, Type.Null },
            //7 - Icemon
            new Type[] { Type.Ice, Type.Null },
            //8 - Dragonice
            new Type[] { Type.Ice, Type.Null },
            //9 - Tirimon
            new Type[] { Type.Normal, Type.Null },
            //10 - Naidormon
            new Type[] { Type.Normal, Type.Null },

        };
        


        
      

        

        public static readonly Stats[] BaseStats = new Stats[]
        {   // 0 - No Pokemon
            new Stats(0f, 0f, 0f, 0f, 0f),
            // 1 - Bulbasaur
            new Stats(45f, 49f, 49f, 65f, 45f),
            // 2 - Ivysaur
            new Stats(60f, 62f, 63f, 80f, 60f),
            // 3 - Venusaur
            new Stats(80f, 82f, 83f, 100f, 80f),
            // 4 - Charmander
            new Stats(39f, 52f, 43f, 50f, 65f),
            // 5 - Charmeleon
            new Stats(58f, 64f, 58f, 65f, 80f),
            // 6 - Charizard
            new Stats(78f, 84f, 78f, 85f, 100f),
            // 7 - Squirtle
            new Stats(44f, 48f, 65f, 50f, 43f),
            // 8 - Wartortle
            new Stats(59f, 63f, 80f, 65f, 58f),
            // 9 - Blastoise
            new Stats(79f, 83f, 100f, 85f, 78f),
            // 10 - Caterpie
            new Stats(45f, 30f, 35f, 20f, 45f),
            
        };


        


        
        
    }
}
