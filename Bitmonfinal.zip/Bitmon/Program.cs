﻿using BitmonGeneration1.Source.Battles;
using BitmonGeneration1.Source.BitmonData;
using BitmonGeneration1.Source.Trainers;
using System;
using System.Threading;

namespace BitmonStadiumConsoleApp
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Write(" Player 1 Enter your name: ");
            string name = Console.ReadLine();
            Console.Clear();

            Console.Write(" Player 2 Enter your name: ");
            string name1 = Console.ReadLine();
            Console.Clear();




            Console.WriteLine(" {0} Select your first Bitmon: ", name);
            Thread.Sleep(2000);
            Bitmon playersBitmon = SelectBitmon.Choose();
            Console.Clear();


            Console.WriteLine("{0} Select your first Bitmon: ", name1);
            Thread.Sleep(2000);
            Bitmon enemyBitmon = SelectBitmon.Choose();
            Console.Clear();

            Console.WriteLine("{0}  Select your 2nd Bitmon: ", name);
            Thread.Sleep(2000);
            Bitmon players2ndBitmon = SelectBitmon.Choose();
            Console.Clear();

            Console.WriteLine("{0} Select your 2nd Bitmon: ", name1);
            Thread.Sleep(2000);
            Bitmon enemy2ndBitmon = SelectBitmon.Choose();
            Console.Clear();

            Console.WriteLine("{0}  Select your 3rd Bitmon: ", name);
            Thread.Sleep(2000);
            Bitmon players3rdBitmon = SelectBitmon.Choose();
            Console.Clear();

            Console.WriteLine("{0} Select your 3rd Bitmon: ", name1);
            Thread.Sleep(2000);
            Bitmon enemy3rdBitmon = SelectBitmon.Choose();
            Console.Clear();





            Trainer Player = new Trainer(name);

            Player.AddToParty(playersBitmon);
            Player.AddToParty(players2ndBitmon);
            Player.AddToParty(players3rdBitmon);


            Trainer Player2 = new Trainer(name1);

            Player2.AddToParty(enemyBitmon);
            Player2.AddToParty(enemy2ndBitmon);
            Player2.AddToParty(enemy3rdBitmon);


            

            Side playerSide = new TrainerSide(Player);
            Side enemySide = new TrainerSide2(Player2);

            ConsoleBattlePlayer.Run(playerSide, enemySide, new BitmonAI());
            //interactuan los 2 pero solo uno pierde vida

            Console.Write("Press enter to exit");
            Console.ReadLine();
        }
    }
}
